import os
from flask import Flask, request, make_response, redirect, render_template, send_from_directory
from flask_orator import Orator, jsonify
import hashlib

### AQUÍ VAS PONIENDO LAS TABLAS QUE VAS CREANDO (sugerencia)
from models import Prueba, Cliente, Indice, Producto, Indice2, Indice3, Indice4, Proveedor, Servicio


os.environ['ORATOR_DATABASES'] = "{'development': {'driver': 'mysql','host': 'MoniPanecito.mysql.pythonanywhere-services.com','database': 'MoniPanecito$default','user': 'MoniPanecito','password': 'Administracion12!'}}"



app = Flask(__name__)
app.config['ORATOR_DATABASES']= {
    'development': {
        'driver': 'mysql',
        'host': 'MoniPanecito.mysql.pythonanywhere-services.com',
        'database': 'MoniPanecito$default',
        'user': 'MoniPanecito',
        'password': 'Administracion12!'
    }
}
db = Orator(app)
DEBUG = True


@app.route('/js/<filename>')
def route_js_files(filename):
    return send_from_directory('js', path=filename)


@app.route('/')
def index():
    return render_template('login.html')

@app.route('/inicio')
def inciio():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('index.html')


###################### LOGIN

@app.route('/loginTry',methods=['POST'])
def login():
    f = request.form
    user=f['username']
    password=f['password']
    hash_object = hashlib.sha256()
    hash_object.update(password.encode())
    hash_hex = hash_object.hexdigest()
    usuario = db.table('users').where('id',user).where('password',hash_hex).get().first()
    if usuario is None:
        return "USUARIO O CONTRASEÑA INCORRECTOS"
    else:
        resp = make_response(redirect('/inicio'))
        resp.set_cookie("user",f['username'],max_age=7200)
        return resp


######################### CLIENTES

@app.route('/clientes')
def clientes():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('clientes.html',clientes=db.table('clientes').get())


@app.route('/clientes/agregar')
def clientes_agregar():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('agregarCliente.html')

@app.route('/clientes/agregar/submit',methods=['POST'])
def cliente_agregar_submit():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    try:
        f = request.form
        nombre = f['nombre']
        tel = f['tel']
        direccion = f['direccion']
        email = f['email']
        c = Cliente()

        ind = Indice.find('clientes')
        indice = ind.actual
        ind.actual=indice+1
        ind.update()

        c.id= indice
        c.nombre=nombre
        c.tel=tel
        c.dir=direccion
        c.correo=email
        c.save()
        return make_response(redirect('/clientes'))
    except Exception as e:
        return "Hubo un error: " + str(e.args)

@app.route('/clientes/editar/<id_cliente>')
def clientes_editar(id_cliente):
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    try:
        c = Cliente.find(id_cliente)
        return render_template('editarCliente.html',cliente=c)
    except Exception as e:
        return "Hubo un error" + str(e.args)

@app.route('/clientes/editar/<id_cliente>/submit',methods=['POST'])
def editar_cliente_submit(id_cliente):
    f = request.form
    c = Cliente.find(id_cliente)
    c.nombre = f['nombre']
    c.tel = f['tel']
    c.dir = f['direccion']
    c.correo = f['email']
    c.update()
    return make_response(redirect('/clientes'))

@app.route('/clientes/eliminar/<id_cliente>')
def clientes_eliminar(id_cliente):
    try:
        c = Cliente.find(id_cliente)
        c.delete()
        return make_response(redirect('/clientes'))
    except Exception as e:
        return(str("ERROR AL ELIMINAR CLIENTE: ")+str(e.args))






######################### PRODUCTOS

@app.route('/productos')
def productos():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('productos.html', productos=db.table('productos').get())

@app.route('/productos/agregar')
def productos_agregar():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('agregarProducto.html')


@app.route('/productos/agregar/submit',methods=['POST'])
def producto_agregar_submit():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    try:
        f = request.form
        nombre = f['nombre']
        marca = f['marca']
        descripcion = f['descripcion']
        precio = f['precio']
        umed = f['umed']
        p = Producto()

        ind2 = Indice2.find('productos')
        indice2 = ind2.actual
        ind2.actual=indice2+1
        ind2.update()

        p.id= indice2
        p.nombre=nombre
        p.marca=marca
        p.descripcion=descripcion
        p.precio=precio
        p.umed=umed
        p.save()
        return make_response(redirect('/productos'))
    except Exception as e:
        return "Hubo un error: " + str(e.args)

@app.route('/productos/editar/<id_producto>')
def productos_editar(id_producto):
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    try:
        p = Producto.find(id_producto)
        return render_template('editarProducto.html',producto=p)
    except Exception as e:
        return "Hubo un error" + str(e.args)

@app.route('/productos/editar/<id_producto>/submit',methods=['POST'])
def editar_producto_submit(id_producto):
    f = request.form
    p = Producto.find(id_producto)
    p.nombre = f['nombre']
    p.marca = f['marca']
    p.precio = f['precio']
    p.descripcion = f['descripcion']
    p.umed = f['umed']
    p.update()
    return make_response(redirect('/productos'))

@app.route('/productos/eliminar/<id_producto>')
def producto_eliminar(id_producto):
    try:
        p = Producto.find(id_producto)
        p.delete()
        return make_response(redirect('/productos'))
    except Exception as e:
        return(str("ERROR AL ELIMINAR CLIENTE: ")+str(e.args))

####################### PROVEEDORES
@app.route('/proveedores')
def proveedores():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('proveedores.html',proveedores=db.table('proveedores').get())
@app.route('/proveedores/agregar')
def proveedores_agregar():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('agregarProveedor.html')

@app.route('/proveedores/agregar/submit',methods=['POST'])
def proveedor_agregar_submit():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    try:
        f = request.form
        nombre = f['nombre']
        telefono = f['telefono']
        correo = f['correo']
        p = Proveedor()

        ind3 = Indice3.find('proveedores')
        indice3 = ind3.actual
        ind3.actual=indice3+1
        ind3.update()

        p.id= indice3
        p.nombre=nombre
        p.telefono=telefono
        p.correo=correo
        p.save()
        return make_response(redirect('/proveedores'))
    except Exception as e:
        return "Hubo un error: " + str(e.args)
@app.route('/proveedores/editar/<id_proveedor>')
def proveedores_editar(id_proveedor):
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    try:
        p = Proveedor.find(id_proveedor)
        return render_template('editarProveedor.html',proveedor=p)
    except Exception as e:
        return "Hubo un error" + str(e.args)
@app.route('/proveedores/eliminar/<id_proveedor>')
def proveedores_eliminar(id_proveedor):
    try:
        p = Proveedor.find(id_proveedor)
        p.delete()
        return make_response(redirect('/proveedores'))
    except Exception as e:
        return(str("ERROR AL ELIMINAR PROVEEDOR: ")+str(e.args))

@app.route('/proveedores/editar/<id_proveedor>/submit',methods=['POST'])
def editar_proveedor_submit(id_proveedor):
    f = request.form
    p = Proveedor.find(id_proveedor)
    p.nombre = f['nombre']
    print(str(f))
    p.telefono = f['telefono']
    p.correo = f['correo']
    p.update()
    return make_response(redirect('/proveedores'))
######################## SERVICIOS
@app.route('/servicios')
def servicios():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('servicios.html',servicios=db.table('servicios').get())
@app.route('/servicios/agregar')
def servicios_agregar():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('agregarServicio.html')
@app.route('/servicios/agregar/submit',methods=['POST'])
def servicio_agregar_submit():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    try:
        f = request.form
        nombre = f['nombre']
        descripcion = f['descripcion']
        precio = f['precio']
        s = Servicio()

        ind4 = Indice4.find('servicios')
        indice4 = ind4.actual
        ind4.actual=indice4+1
        ind4.update()

        s.serv_id= indice4
        s.nombre=nombre
        s.descripcion=descripcion
        s.precio=precio
        s.save()
        return make_response(redirect('/servicios'))
    except Exception as e:
        return "Hubo un error: " + str(e.args)

######################## VENTAS

@app.route('/venta')
def venta():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('venta.html',clientes=db.table('clientes').get(),productos=db.table('productos').get())
######################## VENTA
@app.route('/procesar_venta', methods=['POST'])
def procesar_venta():
    # Obtener los datos del formulario
    f = request.form
    id_cliente = f['cliente']
    productos = f['producto']
    metodo_pago = f['metodo_pago']
    total = f['total']
    importe = f['importe']
    cambio = f['cambio']
    return render_template('ticket_venta.html', id_cliente=id_cliente, productos=productos, metodo_pago=metodo_pago, total=total, importe=importe, cambio=cambio)
######################## CALENDARIO

@app.route('/calendario')
def calendario():
    cookies = request.cookies
    try:
        if  db.table('users').where('id',cookies['user']).get().first() is None:
            return make_response(redirect('/'))
    except:
        return make_response(redirect('/'))
    return render_template('calendario.html')
