#Administracion12!

from flask import Flask
from orator import DatabaseManager, Schema
from flask_orator import Orator


ORATOR_DATABASES = {
    'development': {
        'driver': 'mysql',
        'host': 'MoniPanecito.mysql.pythonanywhere-services.com',
        'database': 'MoniPanecito$default',
        'user': 'MoniPanecito',
        'password': 'Administracion12!'
    }
}

app = Flask(__name__)

app.config['ORATOR_DATABASES'] = {
    'development': {
        'driver': 'mysql',
        'host': 'MoniPanecito.mysql.pythonanywhere-services.com',
        'database': 'MoniPanecito$default',
        'user': 'MoniPanecito',
        'password': 'Administracion12!'
    }
}




db = Orator(app)
schema = Schema(db)

if __name__ == '__main__':
    db.cli.run()
