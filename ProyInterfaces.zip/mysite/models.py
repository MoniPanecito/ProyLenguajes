from flask_orator import Orator
from flask import Flask



ORATOR_DATABASES = {
    'development': {
        'driver': 'mysql',
        'host': 'MoniPanecito.mysql.pythonanywhere-services.com',
        'database': 'MoniPanecito$default',
        'user': 'MoniPanecito',
        'password': 'Administracion12!'
    }
}

app = Flask(__name__)



app.config.from_object(__name__)
db = Orator(app)



class Prueba(db.Model):
    __table__ = 'prueba'
    __primary_key__ = "nombre"

class Indice(db.Model):
    __table__ = 'indices'
    __primary_key__ = "tabla"
class Indice2(db.Model):
    __table__ = 'indices2'
    __primary_key__ = "tabla"
class Indice3(db.Model):
    __table__ = 'indices3'
    __primary_key__ = "tabla"
class Indice4(db.Model):
    __table__ = 'indices4'
    __primary_key__ = "tabla"
class Cliente(db.Model):
    __table__ = 'clientes'
    __primary_key__ = "id"
class Producto(db.Model):
    __table__ = 'productos'
    __primary_key__ = "id"
class Proveedor(db.Model):
    __table__ = 'proveedores'
    __primary_key__ = "id"
class Servicio(db.Model):
    __table__ = 'servicios'
    __primary_key__ = "serv_id"